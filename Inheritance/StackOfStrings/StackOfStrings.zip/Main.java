

public class Main {
    public static void main(String[] args) {

        StackOfStrings stack = new StackOfStrings();

        stack.push("asd1");
        stack.push("asd2");
        stack.push("asd3");
        stack.push("asd4");

    }
}
