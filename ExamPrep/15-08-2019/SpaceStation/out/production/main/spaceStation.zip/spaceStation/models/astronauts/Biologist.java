package spaceStation.models.astronauts;

public class Biologist extends BaseAstronaut {
    private static final double INITIAL_OXYGEN = 70.0;

    public Biologist(String name) {
        super(name, INITIAL_OXYGEN);
    }

    @Override
    public void breath() {
        double oxygenLeft = this.getOxygen() - 5;
        if (oxygenLeft < 0) {
            oxygenLeft = 0;
        }


    }
}
