package viceCity.core.interfaces;

import viceCity.models.guns.Gun;
import viceCity.models.guns.Pistol;
import viceCity.models.guns.Rifle;
import viceCity.models.neighbourhood.GangNeighbourhood;
import viceCity.models.neighbourhood.Neighbourhood;
import viceCity.models.players.CivilPlayer;
import viceCity.models.players.MainPlayer;
import viceCity.models.players.Player;
import viceCity.repositories.GunRepository;
import viceCity.repositories.interfaces.Repository;

import java.util.ArrayList;
import java.util.Collection;

import static viceCity.common.ConstantMessages.*;

public class ControllerImpl implements Controller {
    private Player mainPlayer;
    private Repository<Gun> gunRepository;
    private Collection<Player> civilPlayers;
    private Neighbourhood neighbourhood;

    public ControllerImpl() {
        this.mainPlayer = new MainPlayer();
        this.gunRepository = new GunRepository();
        this.civilPlayers = new ArrayList<>();
        this.neighbourhood = new GangNeighbourhood();
    }

    @Override
    public String addPlayer(String name) {
        Player player = new CivilPlayer(name);
        this.civilPlayers.add(player);
        String msg = String.format(PLAYER_ADDED, name);
        return msg;
    }

    @Override
    public String addGun(String type, String name) {
        String msg = "";

        if (Pistol.class.getSimpleName().equals(type)) {
            this.gunRepository.add(new Pistol(name));
        } else if (Rifle.class.getSimpleName().equals(type)) {
            this.gunRepository.add(new Rifle(name));
        } else {
            return GUN_TYPE_INVALID;
        }
        msg = String.format(GUN_ADDED, name, type);
        return msg;
    }

    @Override
    public String addGunToPlayer(String name) {
        String msg = "";

        if (this.gunRepository.getModels().size() == 0) {
            return GUN_QUEUE_IS_EMPTY;
        }

        Gun gun = null;
        for (Gun model : this.gunRepository.getModels()) {
            gun = model;
            break;
        }
        this.gunRepository.remove(gun);

        if (name.equals("Vercetti")) {
            mainPlayer.getGunRepository().add(gun);
            return String.format(GUN_ADDED_TO_MAIN_PLAYER, gun.getName(), mainPlayer.getName());
        }

        Player player = null;

        for (Player pl : this.civilPlayers) {
            if (pl.getName().equals(name)) {
                player = pl;
            }
        }

        if (player == null) {
            msg = CIVIL_PLAYER_DOES_NOT_EXIST;
        } else {
            player.getGunRepository().add(gun);
            msg = String.format(GUN_ADDED_TO_CIVIL_PLAYER, gun.getName(), player.getName());
        }

        return msg;
    }

    @Override
    public String fight() {
        StringBuilder sb = new StringBuilder();

        this.neighbourhood.action(this.mainPlayer, this.civilPlayers);

        if (mainPlayer.getLifePoints() != 100) {

            boolean harmed = false;
            for (Player civilPlayer : civilPlayers) {

                if (civilPlayer.getLifePoints() != 50) {
                    harmed = true;
                }
            }

            if (harmed) {
                int dead = 0;
                int alive = 0;

                for (Player civilPlayer : civilPlayers) {
                    if (!civilPlayer.isAlive()) {
                        dead++;
                    } else {
                        alive++;
                    }
                }

                sb.append(FIGHT_HAPPENED).append(System.lineSeparator());
                sb.append(String.format(MAIN_PLAYER_LIVE_POINTS_MESSAGE, mainPlayer.getLifePoints()))
                .append(System.lineSeparator());
                sb.append(String.format(MAIN_PLAYER_KILLED_CIVIL_PLAYERS_MESSAGE, dead))
                        .append(System.lineSeparator());
                sb.append(String.format(CIVIL_PLAYERS_LEFT_MESSAGE, alive));
            } else {
                sb.append(FIGHT_HOT_HAPPENED);
            }

        }
        return sb.toString();
    }
}
