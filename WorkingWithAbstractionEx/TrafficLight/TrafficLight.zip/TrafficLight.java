package WorkingWithAbstractionEx.TrafficLight;

public enum TrafficLight {
    RED,
    GREEN,
    YELLOW;
}
